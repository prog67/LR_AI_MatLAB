% Программа преобразует изображение m1 * m1 *3 в размер m * m *1
clc
[FileName, PathName] = uigetfile('*.*');  
I=imread([PathName FileName]);            
subplot(121), imshow(I),title(' Исходное изображение')
%K=imfinfo([PathName FileName]);
size(I)

n=90; m=90;             % требуемый размер изображений
Ir=imresize (I,[n m]);  % приведение изображения к требуемому размеру

B=double(Ir);           % преобразовали изображение в double
B1=B(:,:,1);            % берем первый канал
B1=uint8(B1);           % преобразование матрицы double в изображение
imwrite(B1,'r1.jpg'); % запись изображения в файл

% Проверка преобразования
I1=imread('r1.jpg');  % считываем преобразованное изоражение
size(I1)                % и проверяем его размер
subplot(122), imshow(I1),title(' Преобразованное изображение')