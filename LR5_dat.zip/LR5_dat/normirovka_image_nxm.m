% Программа считывает рисунки из папки ish_Fold_name, которая должна находится 
% в введенной в диалоговом окне папке PathName и приводит изображения к одному 
% размеру n x m, затем записывает их в новую папку new_Fold_name в папке PathName

%PathName = uigetdir;        % диалоговое окно выбора папки PathName



n=90; m=90;                      % требуемый размер изображений

disp('задайте папку с исходными изображениями')
ish_Fold_name = uigetdir;        %имя папки ИСХОДНЫХ изображений 

disp('задайте папку для сохранения нормированных изображений')   % 
new_Fold_name=uigetdir;
new_Fold_name=[new_Fold_name '\'];
%new_Fold_name='\reziz_negativ\'; % имя папки НОРМИРОВАННЫХ изображений (она будет создана)



% _____ Дальше код НЕ ТРОГАТЬ. 
%K=imfinfo([PathName FileName]) % информация об изоражении
% После выполнения прграммы - проверить содержимое новой папки

DatasetPath = [ish_Fold_name '\']; % путь к файлам в папке ИСХОДНЫХ изображений

%new_Fold_Path =[PathName new_Fold_name]      % путь к файлам ПРЕОБРАЗОВАННЫХ изображений

% считываем все изоражения сразу в объект для управления набором изображений 
imds = imageDatastore(DatasetPath, ...      
    'IncludeSubfolders',true, ...           % учитывать содержисое папок
    'LabelSource','foldernames');           % разметить классы по именам папок

labelCount = countEachLabel(imds)           % вывод меток классов по имени папок

k=size(imds.Files);  % определяем размер объекта-изображений
k1=k(1,1);           % фиксируем количество изображений
%mkdir(new_Fold_Path) % создаем новую папку для нормированых изображений
targetSize = [n,m];  % опция, задает желаемый размер рисунка 

% обрезка всех рисунков сразу
imdsReSz = transform(imds,@(x) imresize(x,targetSize)); 

figure;
for i=1:k1
    img1 = read(imdsReSz);
    %imshow(img1)                                       % вывод изоражения на оси
    %D_1 = imresize (img1,[n m])
    D_1=img1(:,:,1);   % выделяем один канал
    imshow(D_1)
    FullName = [new_Fold_name '' num2str(i) '' '.jpg'];% формирование имени очередного файла
    d = getframe;                                      % захват изображения на осях
    imwrite(d(:,:,1).cdata, FullName);                        % сохранение изображения в файл  
end


%  figure; % для прверки отобразим некоторые рисунки
%  perm = randperm(k1,10); % случайные целые числа от 0 до k1, всего 10 штук
%  for i = 1:10
%      subplot(2,5,i);
%      imshow(imds.Files{perm(i)});
% end





