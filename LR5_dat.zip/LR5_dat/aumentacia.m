%% Диалоговое окно выбора папки DigitDataset 
digitDatasetPath = uigetdir; 
imds = imageDatastore(digitDatasetPath, ... 
'IncludeSubfolders',true, ... 
'LabelSource','foldernames'); 
 
%% Создаем аугментатор для предварительного просмотра 
augmenter = imageDataAugmenter( ... 
'RandRotation', [-15, 15], ... 
'RandXTranslation', [-3, 3], ... 
'RandYTranslation', [-3, 3], ... 
'RandXScale', [0.8, 1.2], ... 
'RandYScale', [0.8, 1.2], ... 
'RandXReflection', true); 
 
%% Отобразим оригинальные и аугментированные фото 
figure('Name', 'Оригинальные и аугментированные изображения'); 
perm = randperm(200, 10); 
 
for i = 1:10 
% Считываем оригинальное изображение 
img = readimage(imds, perm(i)); 

% Создаем аугментированную версию 
augmented = augment(augmenter, img);

% Отображаем оригинал 
subplot(4, 5, i); 
imshow(img); 
title('Оригинал'); 

% Отображаем аугментированную версию 
subplot(4, 5, i+10); 
imshow(augmented); 
title('Аугментированное'); 
end 
 
%% Показываем количество классов 
labelCount = countEachLabel(imds); 
nn = size(labelCount); 
col_class = nn(1,1); % выделили количество классов из labelCount 
disp('Распределение классов:'); 
disp(labelCount); 
%% Проверка размера изображений 
img = readimage(imds,1); % считывает изображение № 1 из datastore 
size(img) % если канал один, он не отображается в результате 
 
%% Разделим данные на наборы обучения и валидации 
numTrainFiles = 38; % количество примеров в обучающем наборе в каждом классе 
[imdsTrain, imdsValidation] = splitEachLabel(imds, numTrainFiles, 'randomize'); 
 
% —- Добавление Аугментации —- 
augmenter = imageDataAugmenter( ... 
'RandRotation', [-15, 15], ... % Случайные повороты от -15° до +15° 
'RandXTranslation', [-3, 3], ... % Сдвиги по X 
'RandYTranslation', [-3, 3], ... % Сдвиги по Y 
'RandXScale', [0.8, 1.2], ... % Масштаб по X 
'RandYScale', [0.8, 1.2], ... % Масштаб по Y 
'RandXReflection', true); % Случайное отражение по X 
 
augimdsTrain = augmentedImageDatastore([90 90 3], imdsTrain, ... 
'DataAugmentation', augmenter); % Применяем аугментацию к обучающему набору 
augimdsValidation = augmentedImageDatastore([90 90 3], imdsValidation); % Без аугментации для валидации 
 
%% Архитектура сети 
n_filtr = 8; % количество фильтров в 1-м сверточном слое 
filtr_one = 12; 
 
layers = [ 
imageInputLayer([90 90 3]) % сверточный слой для изображений 
convolution2dLayer(3,filtr_one,'Padding','same') % создаёт n_filtr фильтров размером 3х3 
batchNormalizationLayer 
reluLayer 
maxPooling2dLayer(2,'Stride',2) 
convolution2dLayer(3,2*n_filtr,'Padding','same') 
batchNormalizationLayer 
reluLayer 
maxPooling2dLayer(2,'Stride',2) 
convolution2dLayer(3,4*n_filtr,'Padding','same') 
batchNormalizationLayer 
reluLayer 
fullyConnectedLayer(5) % кол. классов - по количеству цифр 
softmaxLayer 
classificationLayer]; 
 
analyzeNetwork(layers); % анализ корректности построения сети 
 
%% Опции обучения 
options = trainingOptions('sgdm', ... 
'InitialLearnRate',0.01, ... 
'MaxEpochs',15, ... 
'MiniBatchSize',128, ... 
'Shuffle','every-epoch', ... 
'ValidationData',augimdsValidation, ... 
'ValidationFrequency',30, ... 
'Verbose',false, ... 
'Plots','training-progress'); 
 
%% Обучение сети 
net = trainNetwork(augimdsTrain, layers, options); 
 
%% Визуализация фильтров 
layer = 2; 
name = net.Layers(layer).Name; 
channels = 1:n_filtr; 
I = deepDreamImage(net,layer,channels,'PyramidLevels',1); 
 
figure; 
I = imtile(I,'ThumbnailSize',[64 64]); 
imshow(I); 
title(['Layer ',name,' Features']); 
 
layer = 6; % функции на сверточном слое 2 или на 6-м по порядку всех слоев 
channels = 1:2*n_filtr; 
I = deepDreamImage(net,layer,channels,'PyramidLevels',1); 
 
figure; 
I = imtile(I,'ThumbnailSize',[64 64]); 
imshow(I); 
name = net.Layers(layer).Name; 
title(['Layer ',name,' Features']); 
 
%% Проверка на валидационном наборе 
YPred = classify(net, augimdsValidation); 
YValidation = imdsValidation.Labels; 
accuracy = sum(YPred == YValidation) / numel(YValidation); 
disp(['Точность классификации: ', num2str(accuracy)]); 
 
%% Проверка на произвольном изображении 
[FileName, PathName]= uigetfile('*.*'); % Открываем файл с любым рисунком
I = imread([PathName FileName]); % чтение изображения из файла
subplot(1,2,1),imshow(I),title('Исходное изображение');
R = imresize(I,[90 90]); % Приводим изображение к размеру 90х90х3
subplot(1,2,2),imshow(R),title('Нормированное изображение');

YPred = classify(net,R); % Классификация изображения
disp(['Классифицировано как: ', char(YPred)]);