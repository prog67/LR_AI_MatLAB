% RGB = imread('ngc6543a.jpg');
% Y = get(h,'RGB');
% figure
% imagesc(RGB)
% axis image
% zoom(4)


% [IND,map] = rgb2ind(RGB,32);
% figure
% imagesc(IND)
% colormap(map)
% axis image
% 
%  d = getframe;                                      % захват изображения на осях
%      imwrite(d.cdata, '11.jpg');
% zoom(4)
% 
%  [FileName, PathName] = uigetfile('*.JPG');  % диалог открытия файла
% % K=imfinfo([PathName FileName])
% iz = imread(FileName);
%     imshow(iz)
[FileName, PathName] = uigetfile('*.*');  % диалог открытия файла
I=imread([PathName FileName]);              %чтение изображения из файла
K=imfinfo([PathName FileName]);
% DD=I(:,:,1);
imshow(I)
size(I)
%imwrite(gray, 'gray.jpg');
