% Программа распознает цифры набора MNIST
% https://docs.exponenta.ru/deeplearning/ug/create-simple-deep-learning-network-for-classification.html

% а здесь проще: https://docs.exponenta.ru/deeplearning/gs/create-simple-image-classification-network-using-deep-network-designer.html

% digitDatasetPath = fullfile(matlabroot,'toolbox','nnet','nndemos', ...
%     'nndatasets','DigitDataset');
% imds = imageDatastore(digitDatasetPath, ...
%     'IncludeSubfolders',true,'LabelSource','foldernames');


% Отобразим некоторые цифры
% figure;
% perm = randperm(10000,20);
% for i = 1:20
%     subplot(4,5,i);
%     imshow(imds.Files{perm(i)});
% end

%Отобразим количество изображений в каждой категории.
%labelCount таблица, которая содержит метки и количество изображений,%
%имеющих каждую метку. Datastore содержит 1 000 изображений 
%для каждой из цифр 0-9 для в общей сложности 10 000 изображений.
%Можно задать количество классов в последнем полносвязном слое сети
%как OutputSize аргумент.

%labelCount = countEachLabel(imds)

%Необходимо задать размер изображений во входном слое сети. 
%Сначала проверим размер первого изображения в digitData. 
%Каждое изображение 28 28 на 1 пиксель.

% img = readimage(imds,1);
% size(img)

%Разделите данные на наборы данных обучения и валидации, так,
%чтобы каждая категория в наборе обучающих данных содержала
%750 изображений, и набор валидации содержит остающиеся
%изображения от каждой метки. splitEachLabel разделяет 
%datastore digitData в два новых хранилища
%данных, trainDigitData и valDigitData.

% numTrainFiles = 750;
% [imdsTrain,imdsValidation] = splitEachLabel(imds,numTrainFiles,'randomize');

%Архитектура сети Define
% layers = [
%     imageInputLayer([28 28 1])
%     
%     convolution2dLayer(3,8,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     maxPooling2dLayer(2,'Stride',2)
%     
%     convolution2dLayer(3,16,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     maxPooling2dLayer(2,'Stride',2)
%     
%     convolution2dLayer(3,32,'Padding','same')
%     batchNormalizationLayer
%     reluLayer
%     
%     fullyConnectedLayer(10)
%     softmaxLayer
%     classificationLayer];
% 

% опции обучения

% options = trainingOptions('sgdm', ...
%     'InitialLearnRate',0.01, ...
%     'MaxEpochs',4, ...
%     'Shuffle','every-epoch', ...
%     'ValidationData',imdsValidation, ...
%     'ValidationFrequency',30, ...
%     'Verbose',false, ...
%     'Plots','training-progress');

%Обучение сети
%net = trainNetwork(imdsTrain,layers,options);


%Точность является частью меток, которые сеть предсказывает правильно.
%В этом случае больше чем 99% предсказанных меток совпадают с истинными 
%метками набора валидации
YPred = classify(net,imdsValidation);
YValidation = imdsValidation.Labels;

accuracy = sum(YPred == YValidation)/numel(YValidation)









