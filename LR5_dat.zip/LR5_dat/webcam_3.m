
Folder_name = uigetdir;  %выбор папки, где будут храниться фото

camList = webcamlist
cam = webcam(1)
% i=3;
% img1 = snapshot(cam);
% imshow(img1)                                       % вывод изоражения на оси
%     FullName = [Folder_name '\' '' num2str(i) '' '.jpg'];% формирование имени очередного файла
%     d = getframe;                                      % захват изображения на осях
%     imwrite(d.cdata, FullName);                        % сохранение изображения в файл

%preview(cam);  % вывод видео на экран
%Чтобы получить один кадр, используйте функцию моментального снимка.
% Display the frame in a figure window.
%image(img);
% %многократно получить одно изображение, обработать его, а затем сохранить результат.
% %Для этого снимок нужно вызывать в цикле.
for i = 1:50
    pause(0.5)
    img1 = snapshot(cam);
    imshow(img1)
    %image(img);
    FullName = [Folder_name '\' '' num2str(i) '' '.jpg'];% формирование имени очередного файла
    d = getframe;                                      % захват изображения на осях
    imwrite(d.cdata, FullName);     
end
%Когда соединение больше не требуется, очистите связанную переменную.
%clear cam